//The JavaDoc is located in the /inventory_app/javadoc folder!

package main;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * This is the Main file, it initializes the MainScreen.fxml
 * @author Matthew Hathaway
 */


public class Main extends Application {
    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("/view/MainScreen.fxml"));
        stage.setTitle("Main Menu");
        stage.setScene(new Scene(root, 1200, 600));
        stage.show();

    }

    public static void main(String[] args){
        launch(args);
    }
}
